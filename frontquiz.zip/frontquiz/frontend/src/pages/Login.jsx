import React, { useState, useContext } from "react";
import API from "../services/api";
import { useNavigate, Link } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";

const Login = () => {
  const navigate = useNavigate();
  const { login } = useContext(AuthContext);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    try {
      const res = await API.post("/auth/login", { email, password });
      login(res.data.token);
      navigate("/");
    } catch (err) {
      setError(err.response?.data?.message || "Login failed");
    }
  };

  return (
    <div className="auth-wrapper">
      <div className="auth-box">

        {/* LEFT */}
        <div className="auth-left">
          <h2>Welcome Back!</h2>
          <p>
            To keep connected with us<br />
            please login with your info
          </p>
          <Link to="/register">
            <button className="ghost-btn">SIGN UP</button>
          </Link>
        </div>

        {/* RIGHT */}
        <div className="auth-right">
          <h2>Sign In</h2>
          <p className="small-text">Use your email account</p>

          {error && <p className="auth-error">{error}</p>}

          <form onSubmit={handleSubmit}>
            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />

            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />

            <button className="main-btn" type="submit">
              SIGN IN
            </button>
          </form>
        </div>

      </div>
    </div>
  );
};

export default Login;
