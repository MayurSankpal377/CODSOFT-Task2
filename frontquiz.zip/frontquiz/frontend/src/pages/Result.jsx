import React from "react";
import { useLocation, Link } from "react-router-dom";
import "../App.css";

const Result = () => {
  const { state } = useLocation();
  const score = state?.score ?? 0;

  return (
    <div className="result-bg">
      <div className="result-card">
        <h2>Quiz Result</h2>

        <div className="score-circle">
          <span>{score}</span>
        </div>

        <p className="score-text">Your Score</p>

        <Link to="/quizzes" className="result-btn">
          Back to Quizzes
        </Link>
      </div>
    </div>
  );
};

export default Result;
