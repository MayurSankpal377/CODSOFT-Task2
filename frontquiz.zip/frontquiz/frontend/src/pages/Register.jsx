import React, { useState } from "react";
import API from "../services/api";
import { useNavigate, Link } from "react-router-dom";

const Register = () => {
  const navigate = useNavigate();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    try {
      await API.post("/auth/register", { name, email, password });
      navigate("/login");
    } catch (err) {
      setError(err.response?.data?.message || "Registration failed");
    }
  };

  return (
    <div className="auth-wrapper">
      <div className="auth-box">

        {/* LEFT */}
        <div className="auth-left">
          <h2>Hello, Friend!</h2>
          <p>
            Enter your details<br />
            and start your journey
          </p>
          <Link to="/login">
            <button className="ghost-btn">SIGN IN</button>
          </Link>
        </div>

        {/* RIGHT */}
        <div className="auth-right">
          <h2>Create Account</h2>
          <p className="small-text">Use your email for registration</p>

          {error && <p className="auth-error">{error}</p>}

          <form onSubmit={handleSubmit}>
            <input
              type="text"
              placeholder="Name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />

            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />

            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />

            <button className="main-btn" type="submit">
              SIGN UP
            </button>
          </form>
        </div>

      </div>
    </div>
  );
};

export default Register;
