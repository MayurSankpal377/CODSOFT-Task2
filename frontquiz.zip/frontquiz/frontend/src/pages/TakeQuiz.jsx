import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import API from "../services/api";
import "../App.css";

const TakeQuiz = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [questions, setQuestions] = useState([]);
  const [answers, setAnswers] = useState({});

  useEffect(() => {
    API.get(`/quizzes/${id}`).then((res) => {
      setQuestions(res.data.questions);
    });
  }, [id]);

  const submitQuiz = async () => {
    const formattedAnswers = Object.keys(answers).map((qId) => ({
      questionId: Number(qId),
      selectedOptionId: answers[qId],
    }));

    const res = await API.post(`/quizzes/${id}/submit`, {
      quizId: id,
      answers: formattedAnswers,
    });

    navigate(`/result/${id}`, { state: { score: res.data.score } });
  };

  return (
    <div className="takequiz-bg">
      <div className="takequiz-container">
        <h2>Take Quiz</h2>

        {questions.map((q, index) => (
          <div key={q.id} className="takequiz-card">
            <h4>
              {index + 1}. {q.question_text}
            </h4>

            <div className="options">
              {q.options.map((o) => (
                <label key={o.id} className="option-item">
                  <input
                    type="radio"
                    name={`q${q.id}`}
                    onChange={() =>
                      setAnswers({ ...answers, [q.id]: o.id })
                    }
                  />
                  <span>{o.option_text}</span>
                </label>
              ))}
            </div>
          </div>
        ))}

        <button className="submit-btn" onClick={submitQuiz}>
          Submit Quiz
        </button>
      </div>
    </div>
  );
};

export default TakeQuiz;
