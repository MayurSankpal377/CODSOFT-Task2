import React, { useState } from "react";
import API from "../services/api";
import { useNavigate } from "react-router-dom";

const CreateQuiz = () => {
  const navigate = useNavigate();

  const [title, setTitle] = useState("");
  const [question, setQuestion] = useState("");
  const [options, setOptions] = useState([
    { text: "", isCorrect: false },
    { text: "", isCorrect: false },
  ]);
  const [quizId, setQuizId] = useState(null);

  const createQuiz = async () => {
    const res = await API.post("/quizzes", { title });
    setQuizId(res.data.quizId);
  };

  const addQuestion = async () => {
    await API.post("/quizzes/question", {
      quizId,
      questionText: question,
      options,
    });

    setQuestion("");
    setOptions([
      { text: "", isCorrect: false },
      { text: "", isCorrect: false },
    ]);

    alert("Question added");
  };

  const handleOptionChange = (index, field, value) => {
    const newOptions = [...options];
    newOptions[index][field] = value;

    if (field === "isCorrect") {
      newOptions.forEach((o, i) => {
        if (i !== index) o.isCorrect = false;
      });
    }

    setOptions(newOptions);
  };

  return (
    <div className="quiz-bg">
      <div className="quiz-container">

        <h2>Create Quiz</h2>

        {!quizId ? (
          <div className="quiz-vertical">
            <input
              className="quiz-input"
              placeholder="Quiz Title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />

            <button className="quiz-btn" onClick={createQuiz}>
              Create Quiz
            </button>
          </div>
        ) : (
          <>
            <h3>Add Question</h3>

            <input
              className="quiz-input"
              placeholder="Question"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
            />

            {options.map((opt, i) => (
              <div className="option-row" key={i}>
                <input
                  className="quiz-input"
                  placeholder={`Option ${i + 1}`}
                  value={opt.text}
                  onChange={(e) =>
                    handleOptionChange(i, "text", e.target.value)
                  }
                />
                <label>
                  <input
                    type="radio"
                    checked={opt.isCorrect}
                    onChange={() =>
                      handleOptionChange(i, "isCorrect", true)
                    }
                  />
                  Correct
                </label>
              </div>
            ))}

            <button
              className="quiz-btn secondary"
              onClick={() =>
                setOptions([...options, { text: "", isCorrect: false }])
              }
            >
              + Add Option
            </button>

            <button className="quiz-btn" onClick={addQuestion}>
              Save Question
            </button>

            <button
              className="quiz-btn secondary"
              onClick={() => navigate("/quizzes")}
            >
              Finish
            </button>
          </>
        )}
      </div>
    </div>
  );
};

export default CreateQuiz;
