import React, { useEffect, useState } from "react";
import API from "../services/api";
import { useNavigate } from "react-router-dom";
import "../App.css"; // same CSS file use kar

const QuizList = () => {
  const [quizzes, setQuizzes] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchQuizzes = async () => {
      try {
        const res = await API.get("/quizzes");
        setQuizzes(res.data);
      } catch (err) {
        console.error("Failed to load quizzes", err);
      }
    };

    fetchQuizzes();
  }, []);

  return (
    <div className="quizlist-bg">
      <div className="quizlist-container">
        <h2>Available Quizzes</h2>

        {quizzes.length === 0 ? (
          <p className="quizlist-empty">No quizzes available</p>
        ) : (
          quizzes.map((quiz) => (
            <div
              key={quiz.id}
              className="quiz-card"
              onClick={() => navigate(`/quizzes/${quiz.id}`)}
            >
              <h3>{quiz.title}</h3>
              <p>Click to start</p>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default QuizList;
