import React, { useContext } from "react";
import { Link } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import "../App.css";

const Home = () => {
  const { user } = useContext(AuthContext);

  return (
    <div className="home-wrapper">
      <div className="home-box">

        {/* LEFT PANEL */}
        <div className="home-left">
          <h2>Welcome!</h2>
          <p>Hello {user?.name}, start creating or taking quizzes</p>
        </div>

        {/* RIGHT PANEL */}
        <div className="home-right">
          <h2>Online Quiz Maker</h2>

          <div className="home-cards">

            <Link to="/create" className="home-card">
              <h3>Create Quiz</h3>
              <p>Create your own quiz with questions</p>
            </Link>

            <Link to="/quizzes" className="home-card outline">
              <h3>Take Quiz</h3>
              <p>Attempt quizzes created by others</p>
            </Link>

          </div>
        </div>

      </div>
    </div>
  );
};

export default Home;
