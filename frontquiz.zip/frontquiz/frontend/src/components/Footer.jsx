import React from "react";

const Footer = () => {
  return (
    <footer style={styles.footer}>
      <p>© 2026 Quiz Maker. All rights reserved.</p>
    </footer>
  );
};

const styles = {
  footer: {
    textAlign: "center",
    padding: "15px",
    background: "#1e293b",
    color: "white",
    position: "fixed",
    bottom: 0,
    width: "100%",
  },
};

export default Footer;
