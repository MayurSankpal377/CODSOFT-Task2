import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from "./pages/Login";
import "./App.css";

import Register from "./pages/Register";
import Home from "./pages/Home";
import ProtectedRoute from "./components/ProtectedRoute";
import PublicRoute from "./components/PublicRoute";
import TakeQuiz from "./pages/TakeQuiz";
import QuizList from "./pages/QuizList";
import Result from "./pages/Result";
import CreateQuiz from "./pages/CreateQuiz";
function App() {
  return (
    <BrowserRouter>
      <Routes>

        {/* PUBLIC but BLOCK when logged in */}
        <Route
          path="/login"
          element={
            <PublicRoute>
              <Login />
            </PublicRoute>
          }
        />

        <Route
          path="/register"
          element={
            <PublicRoute>
              <Register />
            </PublicRoute>
          }
        />

        {/* PRIVATE */}
        <Route
          path="/"
          element={
            <ProtectedRoute>
              <Home />
            </ProtectedRoute>
          }
        />
        <Route
  path="/create"
  element={
    <ProtectedRoute>
      <CreateQuiz />
    </ProtectedRoute>
  }
/>

<Route
  path="/quizzes"
  element={
    <ProtectedRoute>
      <QuizList />
    </ProtectedRoute>
  }
/>

<Route
  path="/quizzes/:id"
  element={
    <ProtectedRoute>
      <TakeQuiz />
    </ProtectedRoute>
  }
/>

<Route
  path="/result/:id"
  element={
    <ProtectedRoute>
      <Result />
    </ProtectedRoute>
  }
/>

      </Routes>
    </BrowserRouter>
  );
}

export default App;
