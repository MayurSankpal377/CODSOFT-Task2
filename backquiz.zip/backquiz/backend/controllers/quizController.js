const db = require("../config/db");

/* CREATE QUIZ */
exports.createQuiz = (req, res) => {
  const { title } = req.body;
  if (!title) return res.status(400).json({ message: "Title required" });

  db.query(
    "INSERT INTO quizzes (title, user_id) VALUES (?,?)",
    [title, req.user.id],
    (err, result) => {
      if (err) return res.status(500).json(err);
      res.json({ quizId: result.insertId });
    }
  );
};

/* ADD QUESTION */
exports.addQuestion = (req, res) => {
  const { quizId, questionText, options } = req.body;

  db.query(
    "INSERT INTO questions (quiz_id, question_text) VALUES (?,?)",
    [quizId, questionText],
    (err, result) => {
      if (err) return res.status(500).json(err);

      const questionId = result.insertId;
      const values = options.map(o => [
        questionId,
        o.text,
        o.isCorrect ? 1 : 0
      ]);

      db.query(
        "INSERT INTO options (question_id, option_text, is_correct) VALUES ?",
        [values],
        err => {
          if (err) return res.status(500).json(err);
          res.json({ message: "Question added" });
        }
      );
    }
  );
};

/* GET ALL QUIZZES */
exports.getQuizzes = (req, res) => {
  db.query("SELECT * FROM quizzes", (err, rows) => {
    if (err) return res.status(500).json(err);
    res.json(rows);
  });
};

/* GET QUIZ WITH QUESTIONS */
exports.getQuizWithQuestions = (req, res) => {
  const quizId = req.params.id;

  db.query(
    "SELECT * FROM questions WHERE quiz_id = ?",
    [quizId],
    (err, questions) => {
      if (err) return res.status(500).json(err);

      if (questions.length === 0)
        return res.json({ questions: [] });

      const ids = questions.map(q => q.id);

      db.query(
        "SELECT * FROM options WHERE question_id IN (?)",
        [ids],
        (err, options) => {
          if (err) return res.status(500).json(err);

          const data = questions.map(q => ({
            ...q,
            options: options.filter(o => o.question_id === q.id)
          }));

          res.json({ questions: data });
        }
      );
    }
  );
};

/* SUBMIT QUIZ */
exports.submitQuiz = (req, res) => {
  const { quizId, answers } = req.body;

  const qIds = answers.map(a => a.questionId);

  db.query(
    "SELECT * FROM options WHERE question_id IN (?)",
    [qIds],
    (err, options) => {
      if (err) return res.status(500).json(err);

      let score = 0;
      answers.forEach(a => {
        const correct = options.find(
          o => o.question_id === a.questionId && o.is_correct === 1
        );
        if (correct && correct.id === a.selectedOptionId) score++;
      });

      res.json({ score });
    }
  );
};
