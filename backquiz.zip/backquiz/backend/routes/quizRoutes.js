const express = require("express");
const auth = require("../middleware/authMiddleware");
const {
  createQuiz,
  addQuestion,
  getQuizWithQuestions,
  submitQuiz,
  getQuizzes
} = require("../controllers/quizController");

const router = express.Router();

router.post("/", auth, createQuiz);
router.get("/", auth, getQuizzes);
router.post("/question", auth, addQuestion);
router.get("/:id", auth, getQuizWithQuestions);
router.post("/:id/submit", auth, submitQuiz);

module.exports = router;
