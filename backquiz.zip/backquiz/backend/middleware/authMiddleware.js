const jwt = require("jsonwebtoken");

module.exports = (req, res, next) => {
  const authHeader = req.headers.authorization;

  // 1️⃣ token present आहे का
  if (!authHeader) {
    return res.status(401).json({ message: "Authorization token required" });
  }

  // 2️⃣ "Bearer <token>" मधून token काढ
  const parts = authHeader.split(" ");

  if (parts.length !== 2 || parts[0] !== "Bearer") {
    return res.status(401).json({ message: "Token format invalid" });
  }

  const token = parts[1];

  // 3️⃣ verify token
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // decoded = { id, iat, exp }
    req.user = decoded;

    next();
  } catch (err) {
    return res.status(401).json({ message: "Invalid or expired token" });
  }
};
